# TestDaF Digital – Modelltest

Prototype local website for creating interactive Lesen / Hören / Schreiben model tests.

## Open
Open `index.html` directly in a modern browser.

## Current prototype
- Dashboard with Lesen, Hören and Schreiben.
- 7 sample task slots for Lesen and Hören based on the uploaded practice-file structure.
- Per-module timer.
- Hören: local audio file upload/player.
- Schreiben: writing editor, word count, local draft saving.
- Dark mode.
- Responsive layout.

## Important
This is an independent practice interface. It is not an official TestDaF/Telc website and does not reproduce protected branding or proprietary source code.

## Next development
1. Replace sample tasks with real model-test JSON.
2. Add automatic scoring and TDN conversion rules supplied by the test design.
3. Add exact Hören audio + synchronized task controls.
4. Add Schreiben task variants and a structured evaluation form.
5. Add user accounts/progress if a server is desired.
