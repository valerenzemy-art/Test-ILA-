const tasks = {
  lesen: [
    {title:"Nudging als Instrument der Verhaltenssteuerung", format:"Lückentext", text:"Beispielaufgabe: Ergänzen Sie die passenden Ausdrücke im Text.", options:["Option A","Option B","Option C","Option D"]},
    {title:"Der Schwänzeltanz der Honigbienen", format:"Reihenfolge", text:"Ordnen Sie die Aussagen in der richtigen Reihenfolge.", options:["Aussage 1","Aussage 2","Aussage 3","Aussage 4"]},
    {title:"Grüne Infrastruktur gegen urbane Hitzeinseln", format:"Fragen zum Text", text:"Welche Aussage entspricht dem Text?", options:["A","B","C","D"]},
    {title:"Diskussion: Die Vier-Tage-Woche", format:"Sprachhandlungen zuordnen", text:"Ordnen Sie die Aussagen den Sprachhandlungen zu.", options:["Position darstellen","Beispiel nennen","Folge erklären","Gegenargument entkräften"]},
    {title:"Gedrucktes Buch und E-Book im Vergleich", format:"Tabelle", text:"Tragen Sie die Informationen in die passende Tabelle ein.", options:["Gedrucktes Buch","E-Book","Beide","Keine Angabe"]},
    {title:"Lichtverschmutzung in Städten", format:"Problem/Lösung", text:"Welche Lösung wird für welches Problem genannt?", options:["Lösung A","Lösung B","Lösung C","Lösung D"]},
    {title:"Fernstudium in Deutschland", format:"Zusammenfassung mit Fehlern", text:"Identifizieren Sie die fehlerhaften Aussagen.", options:["Aussage 1","Aussage 2","Aussage 3","Aussage 4"]}
  ],
  hoeren: [
    {title:"Ausbau der Fahrradinfrastruktur", format:"Notizen ergänzen", text:"Hören Sie den Beitrag und ergänzen Sie die Notizen.", options:["Lücke 1","Lücke 2","Lücke 3","Lücke 4"]},
    {title:"Tempolimit auf Autobahnen", format:"Reihenfolge", text:"Ordnen Sie die Argumente in der gehörten Reihenfolge.", options:["Argument 1","Argument 2","Argument 3","Argument 4"]},
    {title:"Geothermische Energie", format:"Fragen zum Hörtext", text:"Welche Aussagen werden im Hörtext genannt?", options:["A","B","C","D"]},
    {title:"Home-Office nach der Pandemie", format:"Standpunkte zuordnen", text:"Ordnen Sie die Aussagen den Sprecherinnen/Sprechern zu.", options:["Person A","Person B","Person C","Person D"]},
    {title:"Zwei Bauingenieurinnen im Gespräch", format:"Wer sagt das?", text:"Welche Person äußert welche Aussage?", options:["Sprecherin 1","Sprecherin 2","Beide","Keine"]},
    {title:"Tempo-30-Zonen in Innenstädten", format:"Pro/Contra", text:"Ordnen Sie die Argumente Pro oder Contra zu.", options:["Pro","Contra","Beide","Nicht genannt"]},
    {title:"Ausbau der Solarenergie in Deutschland", format:"Zusammenfassung mit Fehlern", text:"Welche Aussagen stimmen mit dem Vortrag überein?", options:["A","B","C","D"]}
  ]
};

let state = { current:{lesen:0,hoeren:0}, answers:{}, timers:{lesen:3600,hoeren:3600,schreiben:1800} };

function showModule(name){
  document.querySelectorAll(".module").forEach(x=>x.classList.remove("active"));
  document.getElementById(name).classList.add("active");
  document.querySelectorAll(".nav").forEach(x=>x.classList.toggle("active",x.dataset.module===name));
  if(name==="lesen") renderTask("lesen");
  if(name==="hoeren") renderTask("hoeren");
}
document.querySelectorAll(".nav").forEach(b=>b.onclick=()=>showModule(b.dataset.module));
document.querySelectorAll(".module-card").forEach(c=>c.onclick=()=>showModule(c.dataset.go));

function renderTabs(type){
  const el=document.getElementById(type+"Tabs"); el.innerHTML="";
  tasks[type].forEach((t,i)=>{
    const b=document.createElement("button"); b.className="task-tab"+(state.current[type]===i?" active":"");
    b.textContent=`Aufgabe ${i+1}`; b.onclick=()=>{state.current[type]=i;renderTask(type)};
    el.appendChild(b);
  });
}
function renderTask(type){
  renderTabs(type);
  const t=tasks[type][state.current[type]], idx=state.current[type];
  const area=document.getElementById(type+"Task");
  area.innerHTML=`<div class="task-title"><div><p class="eyebrow">AUFGABE ${idx+1} VON ${tasks[type].length}</p><h2>${t.title}</h2></div><span class="task-format">${t.format}</span></div>
  <p class="muted">${t.text}</p>
  <div class="answer-grid">${t.options.map((o,j)=>`<label class="option"><input type="radio" name="${type}-${idx}" value="${j}"> <span>${o}</span></label>`).join("")}</div>
  <div class="controls"><button class="secondary" onclick="prevTask('${type}')">← Zurück</button><button class="primary" onclick="nextTask('${type}')">${idx===tasks[type].length-1?"Modul beenden":"Weiter →"}</button></div>`;
}
function prevTask(type){state.current[type]=Math.max(0,state.current[type]-1);renderTask(type)}
function nextTask(type){state.current[type]=Math.min(tasks[type].length-1,state.current[type]+1);renderTask(type)}

function tick(type){
  state.timers[type]=Math.max(0,state.timers[type]-1);
  const s=state.timers[type], m=String(Math.floor(s/60)).padStart(2,"0"), sec=String(s%60).padStart(2,"0");
  document.getElementById(type+"Timer").textContent=`${m}:${sec}`;
}
setInterval(()=>{tick("lesen");tick("hoeren");tick("schreiben")},1000);

const writing=document.getElementById("writingArea");
function updateWords(){
  const n=writing.value.trim()?writing.value.trim().split(/\s+/).length:0;
  document.getElementById("wordCount").textContent=`${n} Wörter`;
}
writing.addEventListener("input",updateWords);
document.getElementById("saveWriting").onclick=()=>{localStorage.setItem("testdafWriting",writing.value);toast("Entwurf gespeichert.")};
writing.value=localStorage.getItem("testdafWriting")||""; updateWords();

document.getElementById("audioFile").onchange=e=>{
  const file=e.target.files[0]; if(!file)return;
  document.getElementById("audioStatus").textContent=file.name;
  document.getElementById("audioPlayer").src=URL.createObjectURL(file);
};

document.getElementById("themeBtn").onclick=()=>document.body.classList.toggle("dark");
document.getElementById("resetBtn").onclick=()=>{
  if(!confirm("Alle lokalen Antworten und den Schreibentwurf zurücksetzen?"))return;
  localStorage.removeItem("testdafWriting"); location.reload();
};
function toast(msg){const x=document.getElementById("toast");x.textContent=msg;x.classList.add("show");setTimeout(()=>x.classList.remove("show"),1800)}
renderTask("lesen");
